public interface Interface {
    void finish();
}
